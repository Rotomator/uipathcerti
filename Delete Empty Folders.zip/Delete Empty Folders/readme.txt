This sample allows you to select a folder and delete all empty subdirectories
